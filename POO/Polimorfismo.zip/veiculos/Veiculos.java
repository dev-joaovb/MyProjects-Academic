package com.mycompany.veiculos;
import java.util.Scanner;

public class Veiculos {
    String modelo;
    double preco;
    
    ///Metodos...
    public void setModelo(String modelo){
        this.modelo = modelo;
    }
    
    public void setPreco(double preco){
        this.preco = preco;
    }
    
    ///Retorno...
    public String getModelo(){
        return modelo;
    }
    
    public double getPreco(){
        return preco;
    }
    
    public Veiculos(double preco, String modelo){
        setPreco(preco);
        setModelo(modelo);
    }
    
    // Imprimir dados
    public String getTipo(){
        return "Midia: ";
    }
    
    public String getDetalhes(){
        return "Modelo: " + getModelo() + "\n" +
                "Preco: " + getPreco() + "\n";
    }
    
    // Imprimir dados getDetalhes()
    public void printDados(){
        String s = getTipo() + "\n" + getDetalhes() + "\n";
        System.out.println(s);
    }
    
    //Leitura de dados
    public void inserirDados(){
        Scanner in = new Scanner(System.in);
        
        //leitura....
        System.out.printf("\n Modelo: ");
        String mod = in.nextLine();
        System.out.print("\n Informe o preco: ");
        double pre = in.nextDouble();
        in.nextLine(); 
        
        /// mostrar dados executados para as funções set
        setPreco(pre);
        setModelo(mod);
        
    }
    
    
}
