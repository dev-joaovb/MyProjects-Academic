package com.mycompany.veiculos;
import java.util.Scanner;

public class Moto extends Veiculos{
    private int ano;
    
    public Moto(double preco, String modelo, int ano){
        ///Chamando classe Midia
        super(modelo, preco);
        setAno(ano);
    }
    
    //impressão
    public String getTipo(){
        return "Moto: ";
    }
    
    ///Retornando informações dessa classe e da Midia
    public String getDetalhes(){
        return super.getDetalhes() + "\n" +
                "Moto: " + ano + "\n";
    }
    
    public void setAno(int an){
        ano = (an > 0) ? an : 0;
    }
    
    ///Leitura das informações dessa classe e da Midia
    public void inserirDados(){
        super.inserirDados();
        
        Scanner in = new Scanner(System.in);
        // lendo dados....
        System.out.printf("\n Informe o ano da moto: ");
        int an = in.nextInt();
        
        //Enviando...
        setAno(an);
    }
}
