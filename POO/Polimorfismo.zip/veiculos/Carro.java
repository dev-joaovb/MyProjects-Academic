package com.mycompany.veiculos;
import java.util.Scanner;

public class Carro extends Veiculos{
    private double km;
    
    public Carro(double preco, String modelo, double km){
        ///Chamando classe Midia
        super(preco, modelo);
        setKm(km);
    }
    
    //impressão
    public String getTipo(){
        return "Carro: ";
    }
    
    ///Retornando informações dessa classe e da Midia
    public String getDetalhes(){
        return super.getDetalhes() + "\n" +
                "Carro: " + km + "\n";
    }
    
    public void setKm(double km){
        km = (k > 0.0) ? k : 0.0;
    }
    
    ///Leitura das informações dessa classe e da Midia
    public void inserirDados(){
        super.inserirDados();
        
        Scanner in = new Scanner(System.in);
        // lendo dados....
        System.out.printf("\n Informe a quilomentragem do carro: ");
        double k = in.nextInt();
        
        //Enviando...
        setKm(k);
    }
    
}
