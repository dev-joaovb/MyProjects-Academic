package com.mycompany.midia;
import java.util.Scanner;

public class CD extends Midia{
    private int xMusicas;
    
    public CD(double preco, int codigo, String nome, int xMusicas){
        ///Chamando classe Midia
        super(preco, codigo, nome);
        setMusica(xMusicas);
    }
    
    //impressão
    public String getTipo(){
        return "CD: ";
    }
    
    ///Retornando informações dessa classe e da Midia
    public String getDetalhes(){
        return super.getDetalhes() + "\n" +
                "Quantidade de musicas: " + xMusicas + "\n";
    }
    
    public void setMusica(int xmus){
        xMusicas = (xmus > 0) ? xmus : 0;
    }
    
    ///Leitura das informações dessa classe e da Midia
    public void inserirDados(){
        super.inserirDados();
        
        Scanner in = new Scanner(System.in);
        // lendo dados....
        System.out.printf("\n Informe a quantidade de musicas: ");
        int xmus = in.nextInt();
        
        //Enviando...
        setMusica(xmus);
    }
}
