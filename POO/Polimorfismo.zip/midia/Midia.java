//Exercicio de Polimorfismo
//UC19106154
package com.mycompany.midia;
import java.util.Scanner;

public class Midia {
    private double preco;
    private int codigo;
    private String nome;
    
    //Método inserção de valores
    public void setPreco(double preco){
        this.preco = preco;
    }
    
    public void setCodigo(int codigo){
        this.codigo = codigo; 
    }
    
    public void setNome(String nome){
        this.nome = nome;
    }
    
    //Retorno de valores
    public double getPreco(){
        return preco;
    }
    
    public int getCodigo(){
        return codigo;
    }
    
    public String getNome(){
        return nome;
    }
    
    
    public Midia(double preco, int codigo, String nome){
        setPreco(preco);
        setCodigo(codigo);
        setNome(nome);
    }
    
    // Imprimir dados
    public String getTipo(){
        return "Midia: ";
    }
    
    //Retornar em String
    public String getDetalhes(){
        return "Codigo: " + getCodigo() + "\n" +
                "Preco: " + getPreco() + "\n" +
                "Nome: " + getNome() + "\n";
    }
    
    // Imprimir dados getDetalhes()
    public void printDados(){
        String s = getTipo() + "\n" + getDetalhes() + "\n";
        System.out.println(s);
    }
    
    //Leitura de dados
    public void inserirDados(){
        Scanner in = new Scanner(System.in);
        
        //leitura....
        System.out.printf("\n Informe o codigo: ");
        int cod = in.nextInt();
        System.out.print("\n Informe o preco: ");
        double pre = in.nextDouble();
        in.nextLine(); 
        System.out.printf("\n Nome: ");
        String nom = in.nextLine();
        
        /// mostrar dados executados para as funções set
        setPreco(pre);
        setCodigo(cod);
        setNome(nom);
        
    }
}
