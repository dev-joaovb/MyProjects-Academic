package com.mycompany.midia;
import java.util.Scanner;

public class DVD extends Midia{
    private int xFaixas;
    
    public DVD(double preco, int codigo, String nome, int xFaixas){
        /// chamando classe midia....
        super(preco, codigo, nome);
        setFaixas(xFaixas);
    }
    
    ///impressão...
    public String getTipo(){
        return "DVD: ";
    }
    
    ///Retornando essa classe e a midia...
    public String getDetalhes(){
        return super.getDetalhes() + "\n" +
                "Numero de faixas: " + xFaixas + "\n";
    }
    
    public void setFaixas(int xfaix){
        xFaixas = (xfaix > 0) ? xfaix:0;
    }
    
    ///leitura dos dados dessa classe e midia...
    public void inserirDados(){
        //lendo dados classe Midia...
        super.inserirDados();
        
        Scanner in = new Scanner(System.in);
        
        //Lendo...
        System.out.printf("\n Informe o numero de faixas");
        int xfaix = in.nextInt();
        
        //Enviando..
        setFaixas(xfaix);
    }
    
}
