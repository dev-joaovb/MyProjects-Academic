package com.mycompany.midia;
import java.util.Scanner;

public class TesteMidia {
    
    public static void main(String args[]){
        //Criando um vetor
        Midia[] lista = new Midia[10];
        
        int opcao;
        
        ///Preenchendo o vetor com CDs
        for(int i=0; i < 2; i++){
            
            ///Selecione CD ou DVD...
            System.out.printf("Informe 1 para CD e 2 para DVD");
            Scanner in = new Scanner(System.in);
            opcao = in.nextInt();
            if(1 == opcao)
                lista[i] = new CD();
            else
                lista[i] = new DVD();
            lista[i].inserirDados(); /// inserindo dados
        }
        
        //Imprimindo...
        //usando polimorfirmo
        for (int i=0; i < 2; i++)
            lista[i].printDados();
    }
    
}
