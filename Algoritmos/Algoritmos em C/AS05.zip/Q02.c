#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

int main() {
	char nome[5][50];
	int i, quantidade, j;

	printf ("\n Informe a quantidade de nomes que deseja por: ");
	scanf ("%i", &quantidade);
	fflush(stdin);
	for (i=0; i < quantidade; i++) {
		for (j=0; j<1; j++){
			printf ("\n Informe o nome: ");
			fgets(nome[i], 50, stdin);
			//nome[i][j] = toupper(nome[i][j]);
		}
	}
	system("cls");
	for (i=0; i < quantidade; i++) {
		for (j=0; j<1; j++){
			printf("\n\t%s", nome[i]);
			nome[i][j] = toupper(nome[i][j]);
		}
	}
	
	printf("\nConcatenacao.....\n");
	for (i=0; i < quantidade; i++) {
		for (j=0; j<1; j++){
			printf("\n\t%s", nome[i]);
		}
	}

	return 0;
}
