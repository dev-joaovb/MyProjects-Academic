#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

int main(){
	char palavra[100];
	int i;
	
	printf ("\n Informe uma palavra ou frase: ");
	fgets(palavra, 100, stdin);
	printf("\n%s ", palavra);
	for (i=0; i < 100; i++){
	palavra[i] = toupper(palavra[i]);
	}
	printf("\nDestino: %s ", palavra);
	return 0;
}
