#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
// Fun��o
float leValidaNota (){
	float nota;
		do {
			printf ("\n Informe a nota: ");
			scanf ("%f", &nota);
				if (nota < 0 || nota > 10) {
					printf (" A sua nota deve ser entre 0 a 10. Tente novamente...");
				}
		}while (nota < 0 || nota > 10);
	return nota;
}
// Segunda Fun��o
void quantidadeAlunos (int numeroAlunos){
	do{
		printf ("\n Informe a quantidade de alunos.");
		scanf ("%i", numeroAlunos);
		printf ("\n S�o %i , alunos ", numeroAlunos);
			if (numeroAlunos < 1 || numeroAlunos > 49) {
				printf (" S�o %i, alunos", numeroAlunos);
			} 
	} while (numeroAlunos < 1 || numeroAlunos > 49);
}
	
//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>	
int main () {
	setlocale (LC_ALL, "Portuguese");
	float nota [49];
	int contador;
			quantidadeAlunos (nota[49]);
		for (contador = 0; contador < 49; contador++) {
			nota [contador] = leValidaNota ();
		}
		
	return 0;
}
