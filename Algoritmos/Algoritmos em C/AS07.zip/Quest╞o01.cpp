#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
// Fun��o
float leValidaNota (){
	float nota;
		do {
			printf ("\n Informe a nota: ");
			scanf ("%f", &nota);
				if (nota < 0 || nota > 10) {
					printf (" A sua nota deve ser entre 0 a 10. Tente novamente...");
				}
		}while (nota < 0 || nota > 10);
	return nota;
}
int main () {
	setlocale (LC_ALL, "Portuguese");
	float nota [30], maiorNota;
	int contador;
maiorNota = 0;
		for (contador = 0; contador < 30; contador++) {
			nota [contador] = leValidaNota ();
		}
		
	return 0;
}
