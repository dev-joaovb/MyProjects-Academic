#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
// fun��o
int validaIdade (){
	int idade;
		printf ("\n Informe a idade: ");
		scanf ("%i", &idade);
	return idade;
}
int main (){
	setlocale (LC_ALL, "Portuguese");
	int idade[100], contador;
	float mediaIdade;
		for (contador = 0; contador < 100; contador ++){
			printf ("%i- N:", contador + 1);
			scanf ("%i", &idade[contador]);
			mediaIdade = idade [contador] + contador; 
		}
				
				printf ("\n A m�dia da idade �: %f", mediaIdade / 100);
	return 0;
}
