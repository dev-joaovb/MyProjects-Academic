#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
// fun��o
int validaIdade (){
	int dados;
		printf ("\n Informe a idade: ");
		scanf ("%i", &dados);
	return dados;
}
int main (){
	setlocale (LC_ALL, "Portuguese");
	int dados[100], contador;
	float somaDados;
		for (contador = 0; contador < 100; contador ++){
			printf ("%i- N:", contador + 1);
			scanf ("%i", &dados[contador]);
			somaDados = dados [contador] + contador; 
		}
				
				printf ("\n A soma dos dodos �: %f", somaDados);
	return 0;
}
