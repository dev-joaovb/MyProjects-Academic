#include <stdio.h>
#include <stdlib.h>

struct comport{
	int idade[10], notas[10], rendimento[10];
	int resposta;
};
int main(){
	struct comport comportamento, merecimento;
	int j;
	
		for(j=0; j < 2; j++){
			printf ("\nCrianca [%i]", j+1);
			printf ("\n Informe a idade da crianca: ");
			scanf ("%i", &comportamento.idade[j]);
			printf ("\n Informe a nota (1 a 10):");
			scanf ("%i", &comportamento.notas[j]);
			printf ("\n Informe o rendimento (1 a 10): ");
			scanf("%i", &comportamento.rendimento[j]);
		}
		
		for(j=0; j < 2; j++){
			printf("\n Crianca[%i]", j+1);
			printf("\n Idade: %i", comportamento.idade[j]);
			printf("\n Nota: %i", comportamento.notas[j]);
			printf("\n Rendimento: %i", comportamento.rendimento[j]);
		}
		for(j=0; j<2;j++){
			if(comportamento.idade[j] < 11 && comportamento.notas[j] > 9 && comportamento.rendimento[j] > 7){
				printf("\n\nCrianca[%i] recebeu presente!!!", j+1);
			}
		}
		
		merecimento = comportamento;	
		
		for (j=0; j<2; j++){
			printf("\n Crianca[%i]", j+1);
			printf("\n Notas %i", merecimento.notas[j]);
			if(merecimento.idade[j] > 11 && merecimento.notas[j] < 9 && merecimento.rendimento[j] < 7){
				printf ("\n As criancas que nao receberam presentes, pode receber por merecimento!");
				printf("\n Crianca[%i]", j+1);
				printf("\n Informe 1 para merecimento ou 0 para nao receber: ");
				scanf("%i", &merecimento.resposta);
				switch(merecimento.resposta){
					case 1:
						printf("\n Crianca[%i], recebeu o presento por MERECIMENTO", j+1);
						break;
					case 0:
						printf("\n Crianca[%i], nao recebeu MERECIMENTO!", j+1);
						break;
					default:
						printf("\n Informacao anulada, nao foi reconhecido.");
				}
			}
		}
		
	return 0;
}

