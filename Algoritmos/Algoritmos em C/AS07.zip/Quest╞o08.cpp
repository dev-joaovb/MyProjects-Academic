#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
void alfabeto (char *alfabeto) {
	
	for (*alfabeto = 65; *alfabeto <= 90; *alfabeto = *alfabeto +1) {
		printf ("\n Letra: %c",  *alfabeto);
	}

}
// segunda fun��o
void apresentaAlfabeto (char letra){
	printf ("\n Informe uma letra: ");
	scanf ("%c", &letra);
}
// ---------------------------------------
int main () {
	setlocale (LC_ALL, "Portuguese");
	char  local;
	
	apresentaAlfabeto (local);
	
	  alfabeto(&local);
	
	return 0;
}

