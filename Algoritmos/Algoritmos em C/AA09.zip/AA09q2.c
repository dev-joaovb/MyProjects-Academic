#include <stdio.h>
#include <stdlib.h>

int main(){
	int numero, fib1, fib2, fib3;
	fib1 = 0;
	fib2 = 1;
	
	printf("\nInforme o numero deseja para dar inicio a sequencia de Fibonacci: ");
	scanf("%i", &numero);
	
	if(numero < 0){
		printf("\nNumero invalido");
	}else{
		printf("\nSequencia de Fibonacci: 0");
		printf("\n");
		printf("\nSequencia de Fibonacci: 1");
	}
	while(fib2 < numero){
		fib3 = fib2 + fib1;
		printf("\nSequencia de Fibonacci: %i", fib3);
		fib1 = fib2;
		fib2 = fib3;	
	}
	return 0;
}
