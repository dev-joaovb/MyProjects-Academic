#include<stdio.h>
int tamanhoTexto(char *nome);
main(){
	char nome[100];
	int tamanho, i;
	
	fgets(nome, 12, stdin);
	tamanho=tamanhoTexto(nome); //strlen() retorna o tamanho do texto.
	tamanho = strlen(nome[]);
	printf("Nome: %i\n", tamanho);
}
int tamanhoTexto(char *nome){
	int i;
	for(i=0;nome[i]!= '\n' || '\0';i++);
	
	return i;
}


