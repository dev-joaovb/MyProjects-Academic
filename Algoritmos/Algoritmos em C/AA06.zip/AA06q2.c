#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int leValidaQuantidade();

int main() {
	int quantidade, i, j;
	float altura[100], peso[100], imc[100];
	quantidade = leValidaQuantidade();
	printf ("\n %i pessoas", quantidade);
	char nome[quantidade][50];

	for (i=0; i<quantidade; i++) {
		for(j=0;j<1; j++){
			printf("\n %i* Pessoa", i+1);
			fflush(stdin);
			printf("\nInforme o nome: ");
			scanf("%s", &nome[i][j]);
			printf ("\n Informe a altura: ");
			scanf ("%f", &altura[i]);
			printf ("\n Informe o peso: ");
			scanf ("%f", &peso[i]);
			imc[i] = peso[i] / pow(altura[i], 2);
		}
	}
	for (i=0; i < quantidade; i++) {
		printf ("\n %i* Nome: %s", i+1, nome[i]);
		printf ("\n %i* Altura: %f", i+1, altura[i]);
		printf ("\n %i* Peso: %f", i+1, peso[i]);
		printf ("\n %i* IMC: %f", i+1, imc[i]);
		printf("\n");
	}
	return 0;
}

int leValidaQuantidade() {
	int quantidade;
	do {

		printf("\n Informe a quantidade: ");
		scanf ("%i", &quantidade);
		if (quantidade < 0 || quantidade > 100) {
			puts("A quantidade nao pode ser menor que 0 ou maior que 100. Tente novamente...");
		}
	} while(quantidade < 0 || quantidade > 100);
	return quantidade;
}
