#include<stdio.h>
#include<string.h>
#include <ctype.h>

int main() {
	int i, valor = 0;
	char palavra[15], inversa[15];

	printf("\nDigite uma palavra: ");
	gets(palavra);

//Converter a palavra digitada para min�sculas
	for(i = 0; palavra[i]; i++) {
		palavra[i] = tolower(palavra[i]);
	}

//Copiar a palavra digitada para que seja invertida
	strcpy(inversa, palavra);
	printf("\n %s", palavra);
//Inverter a palavra copiada
	strrev(inversa);
	printf("\n %s", inversa);
	valor = strcmp(palavra, inversa);

	if (valor == 0)
		printf("\nA palavra %s eh palindroma\n", palavra);
	else
		printf("\nA palavra %s nao eh palindroma\n", palavra);

	return 0;
}
