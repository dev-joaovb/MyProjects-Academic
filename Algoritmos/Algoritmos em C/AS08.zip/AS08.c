#include <stdio.h>
#include <stdlib.h>

float percentual();
float informarPreco(float *reajuste, float percentual, float *original);

int main(){
	float valor, porcentagem, reajuste, preco;
	
	porcentagem = percentual();
	valor = informarPreco(&reajuste, porcentagem, &preco);
	printf("\n Valor original: %f", preco);
	printf ("\n Percentual: %f", valor);
	return 0;
	
}

float percentual(){
	float reajuste;
	
	printf("\n Informe o percentual para reajuste: ");
	scanf("%f", &reajuste);
}

float informarPreco(float *reajuste, float percentual, float *original){
	float preco;
	
	printf("\n Informe o valor atual: ");
	scanf("%f", &preco);
	*original = preco;
	*reajuste = preco + (preco * (percentual/100));
	return *reajuste;
}
