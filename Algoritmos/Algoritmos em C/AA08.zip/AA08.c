#include <stdio.h>
#include <stdlib.h>

char leValidaNome(char *nome);
float leValidaNota();

int main(){
	char nome[100];
	int i;
	float nota[4], media;
	nome[100] = leValidaNome(nome);
	for(i=0; i<4; i++){
		nota[i] = leValidaNota();
		media = media + nota[i];
	}
	media = media / 4;
	system("cls");
	printf("\n Nome: %s", nome);
	for(i=0; i<4; i++){
		printf("\nNota[%i]: %f", i+1, nota[i]);
	}
	printf("\n Media: %f", media);
	
	return 0;
}

char leValidaNome(char *nome){
	do{
		printf("\n Informe o nome: ");
		gets(nome);
		if(strcmp(nome, "")==0){
			printf("\nEspaco obrigatorio. Tente novamente...");
		}
	}while(strcmp(nome, "")==0);
	return *nome;
}

float leValidaNota(){
	float nota;
	do{
		printf("\n Informe a nota: ");
		scanf("%f", &nota);
		if(nota < 0 || nota > 10){
			printf("\nA nota nao pode ser menor que 0 ou maior que 10. Tente novamente...");
		}
	}while (nota < 0 || nota > 10);
	return nota;
}
