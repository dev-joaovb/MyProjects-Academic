#include <stdio.h>
#include <ctype.h>

int main() {
	char resposta;
	int i, j, reserva;
	int passageiros[4][8] = {{4, 8, 12, 16, 20, 24, 28, 32},
		{3, 7, 11, 15, 19, 23, 27, 31},
		{2, 6, 10, 14, 18, 22, 26, 30},
		{1, 5, 9, 13, 17, 21, 25, 29}
	};
	do {
		for (i=0; i < 4; i++) {
			for (j=0; j < 8; j++) {
				printf ("[%i]", passageiros[i][j]);
			}
			printf("\n");
		}
		printf ("\n Informe o lugar numero do lugar para fazer a reserva: ");
		printf ("\n OBS: O '0' indica que o lugar ja foi reservado!\nR: ");
		scanf ("%i", &reserva);

		for (i=0; i < 4; i++) {
			for(j=0; j < 8; j++) {
				if (passageiros[i][j] == reserva) {
					passageiros[i][j] = 0;
				}
			}
		}
		fflush(stdin);
		printf("\n Deseja continuar?(S/N) \n");
		scanf ("%c", &resposta);
		resposta = toupper(resposta);
	}while (resposta != 'N');



	return 0;
}
