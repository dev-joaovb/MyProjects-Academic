#include <stdio.h>
#include <stdlib.h>

float* aloca(int n);
float maior(float *v, int s);

int main(){
        int j,i;
        float *vetor;
		puts("Digite a quantidade de elementos da rela��o:");
		scanf("%i",&j);
		vetor=aloca(j);
		puts("Digite os elementos da rela��o:");
        for (i=0;i<j;i++) {
                scanf("%f",&vetor[i]);
        }
        printf("Maior = %.2f",maior(vetor,j));
        return 0;
}

float* aloca(int n){
     float *aux;
     aux = (float* ) malloc(n * sizeof(float));
     if(aux == NULL)
     {
          printf("Memoria insuficiente!\n");
          exit(1);
     }
     return aux;
}

float maior(float *v, int s){
        if (s==1) return (v[0]);
        else {
                int x;
                x=maior(v, s-1);
                if (x>v[s-1]) return (x);
                else return (v[s-1]);
        }
}
