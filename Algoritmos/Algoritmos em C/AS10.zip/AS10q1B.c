#include <stdio.h>
#include <stdlib.h>

int main(){
	int numero, maior = 0, menor = 0, i;
	
	for(i=0; i<10; i++){
		printf("\nInforme o numero: ");
		scanf("%i", &numero);
		if(numero > 0){
			if(numero > maior){
				maior = numero;
			}
			if(menor == 0){
				menor = numero;
			}else{
				if(numero < menor){
					menor = numero;
				}
			}
		}
	}
	printf("\n Menor valor: %i", menor);
	printf("\n Maior valor: %i", maior);
	
	
	return 0;
}
