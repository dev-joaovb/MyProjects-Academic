#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
#define buffer fflush(stdin);
struct locatario {
	char nome[50];
	float aluguel;
};


int codigoRegistro(int codigo[], int quantidade);
void nomeLocatario(char *nome);
float valorAluguel();

int main() {
	struct locatario loc[100];
	int indice, codigoInformado;
	int codigo[100], i;
	char resposta;
	float soma;

	do {
		buffer;
		codigo[indice] = codigoRegistro(codigo, indice);
		buffer;
		nomeLocatario(loc[indice].nome);
		loc[indice].aluguel = valorAluguel();
		soma = soma + loc[indice].aluguel;
		indice = indice + 1;
		buffer;
		printf("\n Deseja continuar? (S/N): ");
		scanf("%c", &resposta);
		resposta = toupper(resposta);
	} while(resposta != 'N');

	do {
		printf("\nInforme o codigo do locatario para pesquisa: ");
		scanf("%i", &codigoInformado);
		for(i=0; i<indice; i++) {
			if(codigoInformado == codigo[i]) {
				printf("\nNome do Locatario: %s", loc[i].nome);
				printf("\nCodigo do Locatario: %i", codigoInformado);
				printf("\nAluguel do Locatario: %f", loc[i].aluguel);
			}
		}
		buffer;
		printf("\n Deseja continuar com a proxima? (S/N): ");
		scanf("%c", &resposta);
		resposta = toupper(resposta);
	} while(resposta != 'N');
	printf("\n\n");
	printf("\nSoma de todos os alugueis em atraso: %f", soma);

	return 0;
}
/////////////////////////////////////////////////////
int codigoRegistro(int codigo[], int quantidade) {
	int indice, flag, registro;
	indice = 0;
	do {
		flag = 0;
		printf("\n Informe o codigo de registro: ");
		scanf("%i", &registro);
		for(indice; indice<quantidade; indice++) {
			if(registro == codigo[indice]) {
				flag = 1;
				break;
			}
		}
		if(flag == 1) {
			printf("\n Codigo ja registrado. Tente novamente...");
		}
	} while (flag == 1);
	return registro;
}

void nomeLocatario(char *nome) {
	do {
		printf("\nInforme o nome do Locatario: ");
		gets(nome);
		if(strcmp(nome, "")==0) {
			printf("\nCampo obrigatorio. Tente novamente..");
		}
	} while(strcmp(nome, "")==0);
//	return nome[50];
}

float valorAluguel() {
	float valor;
	printf("\n Informe o valor do aluguel: ");
	scanf("%f", &valor);
	return valor;
}

