#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <ctype.h>
#include <string.h>
#define buffer fflush(stdin); /// Limpar o buffer
#define cls system("cls"); /// LimpaTela
#define pause system("pause") /// pause
#define MAX 1000
/// struct
struct cadastro {
	char nome[100]; /// cadastro de nome
	char email[100]; /// cadastro de email
	int telefone; /// cadastro de telefone
	int estado; /// cadastro de UF
	char cidade[100]; /// cadastro de cidade
	char senha[100]; /// senha para acessar o login
};
///

/// Lista de funcoes
void descricao();
char leValidaTexto(char texto[]);
int lerTelefone();
int leValidaInteiro(int inteiro[], int contador);
int selecionarEstado();
char leValidaSenha(char *senha);
int acessoSenha(char *senha, char *nome, int tentativas);
///
int main() { /// PRINCIPAL
	setlocale(LC_ALL, "Portuguese");
	float carrinho, carrinhoFerramentas, carrinhoParafusos, carrinhoConstrucao, atualizarCarrinho;
	int indice = 0, flag, flag2, quantidade, indice2, continuar;
	char resposta, formaPagamento;
	/// Materiais cadastrados
	float alicateBico = 8.90;
	float alicateUniversal = 12.90;
	float alicateCorte = 10.90;
	float chavePhillips = 2.50;
	float chaveFenda = 2.59;
	float chaveCanhao10mm = 10.90;
	float chaveBoca8mm = 5.90;
	float chaveBoca10mm = 8.90;
	float chaveBoca12mm = 11.90;
	float pacoteParafusoFenda = 5.50;
	float pacoteParafusoPhillips = 5.50;
	float pacoteParafusoSextavado = 10.90;
	float pacoteBuchaS6 = 4.90;
	float pacoteBuchaS8 = 5.90;
	float pacoteBuchaS10 = 6.90;
	float fitaVedaRosca = 1.99;
	float serrote = 11.90;
	///
	/// contador
	int contarAlicateBico;
	int contarAlicateUniversal;
	int contarAlicateCorte;
	int contarChavePhillips;
	int contarChaveFenda;
	int contarChaveCanhao10mm;
	int contarChaveBoca8mm;
	int contarChaveBoca10mm;
	int contarChaveBoca12mm;
	int contarPacoteParafusoFenda;
	int contarPacoteParafusoPhillips;
	int contarPacoteParafusoSextavado;
	int contarPacoteBuchaS6;
	int contarPacoteBuchaS8;
	int contarPacoteBuchaS10;
	int contarFitaVedaRosca;
	int contarSerrote;
	///
	struct cadastro cad[MAX];
	int i, cnpj[MAX], confirmaCnpj, ok, escolha, tentativas, compraConfirmada = 0;
	char selecionar;
	do {

		descricao();
		printf("\n\n");
		pause;
		printf("\n\n\n\n                                                  Loading"); // Exibir a Palavra Loading na tela em branco
		for(i=0; i < 2; i++) { // abrir um la�o de repeti��o com for
			sleep(1); // pausa de 1 segundo
			printf("."); // escrever 1 "." na tela
			fflush(stdout); // atualizar a tela
		}
		do { /// Um cadastro por compra
			do {
				cls;
				printf ("\n\n\t\t\t\t\t   MENU DE OP��ES\n");
				printf("\n - (C) Cadastro ");
				printf("\n - (L) Lista de Produtos ");
				printf("\n - (F) Fale Conosco ");
				printf("\n - (S) Sair ");
				printf("\n\nInforme a op��o desejada: ");
				buffer;
				scanf("%c", &selecionar);
				selecionar = toupper(selecionar);
				buffer;
				switch(selecionar) {
					case 'C':
						if(flag2==1) {
							printf("\n Usuario %s logado!", cad[indice].nome);
						}
						if(flag2 == 0) {
							do {
								cls;
								printf("\n******************* CADASTRO *****************\n");
								//nome
								printf("\nInforme o nome: ");
								cad[indice].nome[100] = leValidaTexto(cad[indice].nome);
								buffer;
								//E-mail
								printf("\nInforme o E-mail: ");
								cad[indice].email[100] = leValidaTexto(cad[indice].email);
								buffer;
								//Telefone
								printf("\n Informe o Telefone: ");
								cad[indice].telefone = lerTelefone();
								//CNPJ
								printf("\n Informe o CNPJ: ");
								cnpj[indice] = leValidaInteiro(cnpj, indice);
								//Selecionar estado
								cls;
								printf("\n Informe o n�mero do Estado de 1 a 27: ");
								cad[indice].estado = selecionarEstado();
								buffer;
								//Cidade
								printf("\n Informe a cidade: ");
								cad[indice].cidade[100] = leValidaTexto(cad[indice].cidade);
								//Senha
								printf("\nDigite uma Senha: ");
								cad[indice].senha[100] = leValidaSenha(cad[indice].senha);
								buffer;
								///
								cls;
								printf("\n\t\t *********** CONFIRMAR DADOS **************\n");
								printf("\n\t\t - Nome: %s", cad[indice].nome);
								printf("\n\t\t - E-mail: %s", cad[indice].email);
								printf("\n\t\t - Telefone: %i", cad[indice].telefone);
								printf("\n\t\t - CNPJ: %i", cnpj[indice]);
								printf("\n\t\t - Cidade: %s\n", cad[indice].cidade);
								printf("\n\t\t ******************************************\n");
								buffer;
								printf("\n\t\t Confirmar cadastro? (S/N)");
								printf("\n\t\tR: ");
								scanf("%c", &resposta);
								resposta = toupper(resposta);
								buffer;
								if(resposta == 'S') {
									flag2 = 1;
									indice2 = indice2 + 1; /// indice2 ser� um aux�lio para pesquisar no for a confirma��o de um CNPJ cadastrado
								}
							} while(resposta != 'S');
						}
						break;
					case 'L':
						///CNPJ
						do {
							i=0;
							flag= 1;
							cls;
							buffer;
							printf("\n\t\t\t  LOGIN ");
							printf("\n\n CNPJ da Empresa: ");
							scanf("%i", &confirmaCnpj);
							for(i; i<indice2; i++) {
								if(confirmaCnpj == cnpj[i]) {
									printf("OK!");
									flag = 0;
									buffer;
									break;
								}
							}
							if(flag == 1) {
								buffer;
								printf("\nCNPJ n�o cadastrado.");
								printf("\nPara cadastrar v� em CADASTRO no Menu principal!");
								printf("\nTentar novamente? (S/N)");
								printf("\nR:");
								scanf("%c", &resposta);
								resposta = toupper(resposta);
								if(resposta == 'N') {
									break;
								}
							}
						} while(resposta == 'S' && flag == 1);
						///Senha do Usuario
						tentativas = 3;
						if(flag == 0) {
							printf("\n Senha: ");
							ok = acessoSenha(cad[i].senha, cad[i].nome, tentativas);
							//	ok = 1; /// vai confirmar o acesso
							if(ok == 0) {
								printf("\n Fa�a um novo cadastro. ");
								flag2 = 0; /// com a flag2 zerada o mesmo usuario vai poder se cadastrar novamente
							}
						}
						contarAlicateBico = 0;
						contarAlicateUniversal = 0;
						contarAlicateCorte = 0;
						contarChavePhillips = 0;
						contarChaveFenda = 0;
						contarChaveCanhao10mm = 0;
						contarChaveBoca8mm = 0;
						contarChaveBoca10mm = 0;
						contarChaveBoca12mm = 0;
						contarPacoteParafusoFenda = 0;
						contarPacoteParafusoPhillips = 0;
						contarPacoteParafusoSextavado = 0;
						contarPacoteBuchaS6 = 0;
						contarPacoteBuchaS8 = 0;
						contarPacoteBuchaS10 = 0;
						contarFitaVedaRosca = 0;
						contarSerrote = 0;
						carrinho = 0;
						carrinhoParafusos = 0;
						carrinhoConstrucao = 0;
						carrinhoFerramentas = 0;
						/// Materiais de ferragens
						if(ok == 1) {
							do {
								do {
									buffer;
									cls;
									printf("\n\t\t\t    MENU ");
									printf("\n (F)- Ferramentas ");
									printf("\n (P)- Parafusos ");
									printf("\n (C)- Constru��o ");
									printf("\n (D)- Pagamento \n");
									printf("\n Selecione uma op��o acima: ");
									printf("\nR: ");
									scanf("%c", &selecionar);
									selecionar = toupper(selecionar);
									switch(selecionar) {
										case 'F':
											continuar = 1;
											do {
												cls;
												buffer;
												if(continuar == 1) {
													carrinho = carrinho + carrinhoFerramentas;
												}
												printf("\n\t\t\t    FERRAMENTAS ");
												printf("\n (1)- Chave Fenda ");
												printf("\n (2)- Chave Phillips ");
												printf("\n (3)- Chave Canh�o 10mm ");
												printf("\n (4)- Chave de Boca 8mm ");
												printf("\n (5)- Chave de Boca 10mm ");
												printf("\n (6)- Chave de Boca 12mm ");
												printf("\n (7)- Alicate de Bico ");
												printf("\n (8)- Alicate Universal ");
												printf("\n (9)- Alicate de Corte ");
												printf("\n (0)- Sair ");
												printf("\n *************************\n");
												printf("\n Carrinho Ferramentas: R$%.2f\n", carrinhoFerramentas);
												printf("\n *************************");
												printf("\n\n Para consultar o valor de um item, informe o numero ao lado de cada item.");
												printf("\nR: ");
												scanf("%i", &escolha);
												switch(escolha) {
													case 1:
														cls;
														buffer;
														printf("\n (1)- Chave Fenda: R$2,59 ");
														printf("\n Adicionar ao carrinho? (S/N)");
														scanf("%c", &resposta);
														resposta = toupper(resposta);
														if(resposta == 'S') {
															printf("\nQuantidade \nR: ");
															scanf("%i", &quantidade);
															carrinhoFerramentas = carrinhoFerramentas + (chaveFenda * quantidade);
															contarChaveFenda = contarChaveFenda + quantidade;
														}
														break;
													case 2:
														cls;
														buffer;
														printf("\n (2)- Chave Phillips: R$2,50 ");
														printf("\n Adicionar ao carrinho? (S/N)");
														scanf("%c", &resposta);
														resposta = toupper(resposta);
														if(resposta == 'S') {
															printf("\nQuantidade \nR: ");
															scanf("%i", &quantidade);
															carrinhoFerramentas = carrinhoFerramentas + (chavePhillips * quantidade);
															contarChavePhillips = contarChavePhillips + quantidade;
														}
														break;
													case 3:
														cls;
														buffer;
														printf("\n (3)- Chave Canh�o 10mm: R$10,90 ");
														printf("\n Adicionar ao carrinho? (S/N)");
														scanf("%c", &resposta);
														resposta = toupper(resposta);
														if(resposta == 'S') {
															printf("\nQuantidade \nR: ");
															scanf("%i", &quantidade);
															carrinhoFerramentas = carrinhoFerramentas + (chaveCanhao10mm * quantidade);
															contarChaveCanhao10mm = contarChaveCanhao10mm + quantidade;
														}
														break;
													case 4:
														cls;
														buffer;
														printf("\n (4)- Chave de Boca 8mm: R$5,90 ");
														printf("\n Adicionar ao carrinho? (S/N)");
														scanf("%c", &resposta);
														resposta = toupper(resposta);
														if(resposta == 'S') {
															printf("\nQuantidade \nR: ");
															scanf("%i", &quantidade);
															carrinhoFerramentas = carrinhoFerramentas + (chaveBoca8mm * quantidade);
															contarChaveBoca8mm = contarChaveBoca8mm + quantidade;
														}
														break;
													case 5:
														cls;
														buffer;
														printf("\n (5)- Chave de Boca 10mm: R$8,90 ");
														printf("\n Adicionar ao carrinho? (S/N)");
														scanf("%c", &resposta);
														resposta = toupper(resposta);
														if(resposta == 'S') {
															printf("\nQuantidade \nR: ");
															scanf("%i", &quantidade);
															carrinhoFerramentas = carrinhoFerramentas + (chaveBoca10mm * quantidade);
															contarChaveBoca10mm = contarChaveBoca10mm + quantidade;
														}
														break;
													case 6:
														cls;
														buffer;
														printf("\n (6)- Chave de Boca 10mm: R$11,90 ");
														printf("\n Adicionar ao carrinho? (S/N)");
														scanf("%c", &resposta);
														resposta = toupper(resposta);
														if(resposta == 'S') {
															printf("\nQuantidade \nR: ");
															scanf("%i", &quantidade);
															carrinhoFerramentas = carrinhoFerramentas + (chaveBoca12mm * quantidade);
															contarChaveBoca12mm = contarChaveBoca12mm + quantidade;
														}
														break;
													case 7:
														cls;
														buffer;
														printf("\n (7)- Alicate de Bico: R$8,90 ");
														printf("\n Adicionar ao carrinho? (S/N)");
														scanf("%c", &resposta);
														resposta = toupper(resposta);
														if(resposta == 'S') {
															printf("\nQuantidade \nR: ");
															scanf("%i", &quantidade);
															carrinhoFerramentas = carrinhoFerramentas + (alicateBico * quantidade);
															contarAlicateBico = contarAlicateBico + quantidade;
														}
														break;
													case 8:
														cls;
														buffer;
														printf("\n (8)- Alicate Universal: R$12,90 ");
														printf("\n Adicionar ao carrinho? (S/N)");
														scanf("%c", &resposta);
														resposta = toupper(resposta);
														if(resposta == 'S') {
															printf("\nQuantidade \nR: ");
															scanf("%i", &quantidade);
															carrinhoFerramentas = carrinhoFerramentas + (alicateUniversal * quantidade);
															contarAlicateUniversal = contarAlicateUniversal + quantidade;
														}
														break;
													case 9:
														cls;
														buffer;
														printf("\n (9)- Alicate de Corte: R$10,90 ");
														printf("\n Adicionar ao carrinho? (S/N)");
														scanf("%c", &resposta);
														resposta = toupper(resposta);
														if(resposta == 'S') {
															printf("\nQuantidade \nR: ");
															scanf("%i", &quantidade);
															carrinhoFerramentas = carrinhoFerramentas + (alicateCorte * quantidade);
															contarAlicateCorte = contarAlicateCorte + quantidade;
														}
														break;
												}

												buffer;
												cls;
												printf("\n****** Itens no carrinho. ******\n");
												if(carrinhoFerramentas == 0) {
													printf("\n Nenhum item foi adicionado ao carrinho.");
												}
												if(carrinhoFerramentas > 0) {
													if(contarChaveFenda>0) {
														printf("\n Chave de Fenda: %i", contarChaveFenda);
													}
													if(contarChavePhillips>0) {
														printf("\n Chave Phillips: %i", contarChavePhillips);
													}
													if(contarChaveCanhao10mm>0) {
														printf("\n Chave Canh�o 10mm: %i", contarChaveCanhao10mm);
													}
													if(contarChaveBoca8mm>0) {
														printf("\n Chave de Boca 8mm: %i", contarChaveBoca8mm);
													}
													if(contarChaveBoca10mm>0) {
														printf("\n Chave de Boca 10mm: %i", contarChaveBoca10mm);
													}
													if(contarChaveBoca12mm>0) {
														printf("\n Chave de Boca 12mm: %i", contarChaveBoca12mm);
													}
													if(contarAlicateBico>0) {
														printf("\n Alicate de Bico: %i", contarAlicateBico);
													}
													if(contarAlicateUniversal>0) {
														printf("\n Alicate Universal: %i", contarAlicateUniversal);
													}
													if(contarAlicateCorte>0) {
														printf("\n Alicate de Corte: %i", contarAlicateCorte);
													}
												}


												if(escolha == 0) {
													continuar = 0;
													carrinhoFerramentas = 0;
												}

											} while(escolha != 0);
											buffer;
											printf("\n");
											pause;
											cls;
											break;
										case 'P':
											continuar = 1;
											do {
												cls;
												buffer;
												if(continuar == 1) {
													carrinho = carrinho + carrinhoParafusos;
												}
												printf("\n\t\t\t    PARAFUSOS ");
												printf("\n (1)- Pacote Parafuso Fenda ");
												printf("\n (2)- Pacote Parafuso Phillips ");
												printf("\n (3)- Pacote Parafuso Sextavado ");
												printf("\n (0)- Sair ");
												printf("\n *************************\n");
												printf("\n Carrinho Parafusos: R$%.2f\n", carrinhoParafusos);
												printf("\n *************************");
												printf("\n\n Para consultar o valor de um item, informe o numero ao lado de cada item.");
												printf("\nR: ");
												scanf("%i", &escolha);
												switch(escolha) {
													case 1:
														cls;
														buffer;
														printf("\n (1)- Pacote Parafuso Fenda: R$5,50 ");
														printf("\n Adicionar ao carrinho? (S/N)");
														scanf("%c", &resposta);
														resposta = toupper(resposta);
														if(resposta == 'S') {
															printf("\nQuantidade \nR: ");
															scanf("%i", &quantidade);
															carrinhoParafusos = carrinhoParafusos + (pacoteParafusoFenda * quantidade);
															contarPacoteParafusoFenda = contarPacoteParafusoFenda + quantidade;
														}
														break;
													case 2:
														cls;
														buffer;
														printf("\n (2)- Pacote Parafuso Phillips: R$5,50 ");
														printf("\n Adicionar ao carrinho? (S/N)");
														scanf("%c", &resposta);
														resposta = toupper(resposta);
														if(resposta == 'S') {
															printf("\nQuantidade \nR: ");
															scanf("%i", &quantidade);
															carrinhoParafusos = carrinhoParafusos + (pacoteParafusoPhillips * quantidade);
															contarPacoteParafusoPhillips = contarPacoteParafusoPhillips + quantidade;
														}
														break;
													case 3:
														cls;
														buffer;
														printf("\n (3)- Pacote Parafuso Sextavado: R$10,90 ");
														printf("\n Adicionar ao carrinho? (S/N)");
														scanf("%c", &resposta);
														resposta = toupper(resposta);
														if(resposta == 'S') {
															printf("\nQuantidade \nR: ");
															scanf("%i", &quantidade);
															carrinhoParafusos = carrinhoParafusos + (pacoteParafusoSextavado * quantidade);
															contarPacoteParafusoSextavado = contarPacoteParafusoSextavado + quantidade;
														}
														break;
												}

												buffer;
												cls;
												printf("\n****** Itens no carrinho. ******\n");
												if(carrinhoParafusos == 0) {
													printf("\n Nenhum item foi adicionado ao carrinho.");
												}
												if(carrinhoParafusos > 0) {
													if(contarPacoteParafusoFenda>0) {
														printf("\n Pacote Parafuso Fenda: %i", contarPacoteParafusoFenda);
													}
													if(contarPacoteParafusoPhillips>0) {
														printf("\n Pacote Parafuso Phillips: %i", contarPacoteParafusoPhillips);
													}
													if(contarPacoteParafusoSextavado>0) {
														printf("\n Pacote Parafuso Sextavado: %i", contarPacoteParafusoSextavado);
													}
												}

												if(escolha == 0) {
													continuar = 0;
													carrinhoParafusos = 0;
												}
												
											} while(escolha != 0);
											buffer;
											printf("\n");
											pause;
											cls;
											break;
										case 'C':
											continuar = 1;
											do {
												cls;
												buffer;
												if(continuar == 1) {
													carrinho = carrinho + carrinhoConstrucao;
												}
												printf("\n\t\t\t    CONSTRU��O ");
												printf("\n (1)- Pacote Bucha S6 ");
												printf("\n (2)- Pacote Bucha S8 ");
												printf("\n (3)- Pacote Bucha S10 ");
												printf("\n (4)- Fita Veda Rosca ");
												printf("\n (5)- Serrote ");
												printf("\n (0)- Sair ");
												printf("\n *************************");
												printf("\n Carrinho Constru��o: R$%.2f\n", carrinhoConstrucao);
												printf("\n *************************");
												printf("\n\n Para consultar o valor de um item, informe o numero ao lado de cada item.");
												printf("\nR: ");
												scanf("%i", &escolha);
												switch(escolha) {
													case 1:
														cls;
														buffer;
														printf("\n (1)- Pacote Bucha S6: R$4,90 ");
														printf("\n Adicionar ao carrinho? (S/N)");
														scanf("%c", &resposta);
														resposta = toupper(resposta);
														if(resposta == 'S') {
															printf("\nQuantidade \nR: ");
															scanf("%i", &quantidade);
															carrinhoConstrucao = carrinhoConstrucao + (pacoteBuchaS6 * quantidade);
															contarPacoteBuchaS6 = contarPacoteBuchaS6 + quantidade;
														}
														break;
													case 2:
														cls;
														buffer;
														printf("\n (2)- Pacote Bucha S8: R$5,90 ");
														printf("\n Adicionar ao carrinho? (S/N)");
														scanf("%c", &resposta);
														resposta = toupper(resposta);
														if(resposta == 'S') {
															printf("\nQuantidade \nR: ");
															scanf("%i", &quantidade);
															carrinhoConstrucao = carrinhoConstrucao + (pacoteBuchaS8 * quantidade);
															contarPacoteBuchaS8 = contarPacoteBuchaS8 + quantidade;
														}
														break;
													case 3:
														cls;
														buffer;
														printf("\n (3)- Pacote Bucha S10: R$6,90 ");
														printf("\n Adicionar ao carrinho? (S/N)");
														scanf("%c", &resposta);
														resposta = toupper(resposta);
														if(resposta == 'S') {
															printf("\nQuantidade \nR: ");
															scanf("%i", &quantidade);
															carrinhoConstrucao = carrinhoConstrucao + (pacoteBuchaS10 * quantidade);
															contarPacoteBuchaS10 = contarPacoteBuchaS10 + quantidade;
														}
														break;
													case 4:
														cls;
														buffer;
														printf("\n (4)- Fita Veda Rosca: R$1,99 ");
														printf("\n Adicionar ao carrinho? (S/N)");
														scanf("%c", &resposta);
														resposta = toupper(resposta);
														if(resposta == 'S') {
															printf("\nQuantidade \nR: ");
															scanf("%i", &quantidade);
															carrinhoConstrucao = carrinhoConstrucao + (fitaVedaRosca * quantidade);
															contarFitaVedaRosca = contarFitaVedaRosca + quantidade;
														}
														break;
													case 5:
														cls;
														buffer;
														printf("\n (5)- Serrote: R$11,90 ");
														printf("\n Adicionar ao carrinho? (S/N)");
														scanf("%c", &resposta);
														resposta = toupper(resposta);
														if(resposta == 'S') {
															printf("\nQuantidade \nR: ");
															scanf("%i", &quantidade);
															carrinhoConstrucao = carrinhoConstrucao + (serrote * quantidade);
															contarSerrote = contarSerrote + quantidade;
														}
														break;
												}


												buffer;
												cls;
												printf("\n****** Itens no carrinho. ******\n");
												if(carrinhoConstrucao == 0) {
													printf("\n Nenhum item foi adicionado ao carrinho.");
												}
												if(carrinhoConstrucao > 0) {
													if(contarPacoteBuchaS6>0) {
														printf("\n Pacote Bucha S6: %i", contarPacoteBuchaS6);
													}
													if(contarPacoteBuchaS8>0) {
														printf("\n Pacote Bucha S8: %i", contarPacoteBuchaS8);
													}
													if(contarPacoteBuchaS10>0) {
														printf("\n Pacote Bucha S10: %i", contarPacoteBuchaS10);
													}
													if(contarFitaVedaRosca>0) {
														printf("\n Fita Veda Rosca: %i", contarFitaVedaRosca);
													}
													if(contarSerrote>0) {
														printf("\n Serrote: %i", contarSerrote);
													}
												}

												if(escolha == 0) {
													continuar = 0;
													carrinhoConstrucao = 0;
												}
											
											} while(escolha != 0);
											buffer;
											printf("\n");
											pause;
											cls;
											break;
										case 'D':
											buffer;
											cls;
											if(carrinho > 0) {
												printf("************* CARRINHO *************");
												if(contarChaveFenda>0) {
													printf("\n Chave de Fenda: %i", contarChaveFenda);
												}
												if(contarChavePhillips>0) {
													printf("\n Chave Phillips: %i", contarChavePhillips);
												}
												if(contarChaveCanhao10mm>0) {
													printf("\n Chave Canh�o 10mm: %i", contarChaveCanhao10mm);
												}
												if(contarChaveBoca8mm>0) {
													printf("\n Chave de Boca 8mm: %i", contarChaveBoca8mm);
												}
												if(contarChaveBoca10mm>0) {
													printf("\n Chave de Boca 10mm: %i", contarChaveBoca10mm);
												}
												if(contarChaveBoca12mm>0) {
													printf("\n Chave de Boca 12mm: %i", contarChaveBoca12mm);
												}
												if(contarAlicateBico>0) {
													printf("\n Alicate de Bico: %i", contarAlicateBico);
												}
												if(contarAlicateUniversal>0) {
													printf("\n Alicate Universal: %i", contarAlicateUniversal);
												}
												if(contarAlicateCorte>0) {
													printf("\n Alicate de Corte: %i", contarAlicateCorte);
												}
												if(contarPacoteParafusoFenda>0) {
													printf("\n Pacote Parafuso Fenda: %i", contarPacoteParafusoFenda);
												}
												if(contarPacoteParafusoPhillips>0) {
													printf("\n Pacote Parafuso Phillips: %i", contarPacoteParafusoPhillips);
												}
												if(contarPacoteParafusoSextavado>0) {
													printf("\n Pacote Parafuso Sextavado: %i", contarPacoteParafusoSextavado);
												}
												if(contarPacoteBuchaS6>0) {
													printf("\n Pacote Bucha S6: %i", contarPacoteBuchaS6);
												}
												if(contarPacoteBuchaS8>0) {
													printf("\n Pacote Bucha S8: %i", contarPacoteBuchaS8);
												}
												if(contarPacoteBuchaS10>0) {
													printf("\n Pacote Bucha S10: %i", contarPacoteBuchaS10);
												}
												if(contarFitaVedaRosca>0) {
													printf("\n Fita Veda Rosca: %i", contarFitaVedaRosca);
												}
												if(contarSerrote>0) {
													printf("\n Serrote: %i", contarSerrote);
												}
												atualizarCarrinho = carrinho;
												do {
													printf("\n\n TOTAL: R$%.2f", carrinho);
													//// forma de pagamento
													printf("\n Forma de pagamento: ");
													printf("\n (D) - Debito ");
													printf("\n (C) - Cr�dito ");
													printf("\nR: ");
													scanf("%c", &formaPagamento);
													formaPagamento = toupper(formaPagamento);
													switch(formaPagamento) {
														case 'D':
															printf("\n Debito ");
															if(carrinho > 1000.00) {
																carrinho = carrinho - (carrinho * 0.03);
																printf("\n Ser� concedido um desconto de 3%% em compras acima de R$1000,00. ");
															}
															printf("\n TOTAL A PAGAR: %.2f", carrinho);
															printf("\n Confirmar pagamento? (S/N)");
															buffer;
															scanf("%c", &resposta);
															resposta = toupper(resposta);
															buffer;
															if(resposta == 'S') {
																cls;
																printf("\n ********* PAGAMENTO CONFIRMADO *********");
																printf("\n\n");
																if(contarChaveFenda>0) {
																	printf("\n Chave de Fenda: %i", contarChaveFenda);
																	chaveFenda = chaveFenda * contarChaveFenda;
																	printf("\n Total: R$%.2f", chaveFenda);
																}
																if(contarChavePhillips>0) {
																	printf("\n Chave Phillips: %i", contarChavePhillips);
																	chavePhillips = chavePhillips * contarChavePhillips;
																	printf("\n Total: R$%.2f", chavePhillips);
																}
																if(contarChaveCanhao10mm>0) {
																	printf("\n Chave Canh�o 10mm: %i", contarChaveCanhao10mm);
																	chaveCanhao10mm = chaveCanhao10mm * contarChaveCanhao10mm;
																	printf("\n Total: R$%.2f", chaveCanhao10mm);
																}
																if(contarChaveBoca8mm>0) {
																	printf("\n Chave de Boca 8mm: %i", contarChaveBoca8mm);
																	chaveBoca8mm = chaveBoca8mm * contarChaveBoca8mm;
																	printf("\n Total: R$%.2f", chaveBoca8mm);
																}
																if(contarChaveBoca10mm>0) {
																	printf("\n Chave de Boca 10mm: %i", contarChaveBoca10mm);
																	chaveBoca10mm = chaveBoca10mm * contarChaveBoca10mm;
																	printf("\n Total: R$%.2f", chaveBoca10mm);
																}
																if(contarChaveBoca12mm>0) {
																	printf("\n Chave de Boca 12mm: %i", contarChaveBoca12mm);
																	chaveBoca12mm = chaveBoca12mm * contarChaveBoca12mm;
																	printf("\n Total: R$%.2f", chaveBoca12mm);
																}
																if(contarAlicateBico>0) {
																	printf("\n Alicate de Bico: %i", contarAlicateBico);
																	alicateBico = alicateBico * contarAlicateBico;
																	printf("\n Total: R$%.2f", alicateBico);
																}
																if(contarAlicateUniversal>0) {
																	printf("\n Alicate Universal: %i", contarAlicateUniversal);
																	alicateUniversal = alicateUniversal * contarAlicateUniversal;
																	printf("\n Total: R$%.2f", alicateUniversal);
																}
																if(contarAlicateCorte>0) {
																	printf("\n Alicate de Corte: %i", contarAlicateCorte);
																	alicateCorte = alicateCorte * contarAlicateCorte;
																	printf("\n Total: R$%.2f", alicateCorte);
																}
																if(contarPacoteParafusoFenda>0) {
																	printf("\n Pacote Parafuso Fenda: %i", contarPacoteParafusoFenda);
																	pacoteParafusoFenda = pacoteParafusoFenda * contarPacoteParafusoFenda;
																	printf("\n Total: R$%.2f", pacoteParafusoFenda);
																}
																if(contarPacoteParafusoPhillips>0) {
																	printf("\n Pacote Parafuso Phillips: %i", contarPacoteParafusoPhillips);
																	pacoteParafusoPhillips = pacoteParafusoPhillips * contarPacoteParafusoPhillips;
																	printf("\n Total: R$%.2f", pacoteParafusoPhillips);
																}
																if(contarPacoteParafusoSextavado>0) {
																	printf("\n Pacote Parafuso Sextavado: %i", contarPacoteParafusoSextavado);
																	pacoteParafusoSextavado = pacoteParafusoSextavado * contarPacoteParafusoSextavado;
																	printf("\n Total: R$%.2f", pacoteParafusoSextavado);
																}
																if(contarPacoteBuchaS6>0) {
																	printf("\n Pacote Bucha S6: %i", contarPacoteBuchaS6);
																	pacoteBuchaS6 = pacoteBuchaS6 * contarPacoteBuchaS6;
																	printf("\n Total: R$%.2f", pacoteBuchaS6);
																}
																if(contarPacoteBuchaS8>0) {
																	printf("\n Pacote Bucha S8: %i", contarPacoteBuchaS8);
																	pacoteBuchaS8 = pacoteBuchaS8 * contarPacoteBuchaS8;
																	printf("\n Total: R$%.2f", pacoteBuchaS8);
																}
																if(contarPacoteBuchaS10>0) {
																	printf("\n Pacote Bucha S10: %i", contarPacoteBuchaS10);
																	pacoteBuchaS10 = pacoteBuchaS10 * contarPacoteBuchaS10;
																	printf("\n Total: R$%.2f", pacoteBuchaS10);
																}
																if(contarFitaVedaRosca>0) {
																	printf("\n Fita Veda Rosca: %i", contarFitaVedaRosca);
																	fitaVedaRosca = fitaVedaRosca * contarFitaVedaRosca;
																	printf("\n Total: R$%.2f", fitaVedaRosca);
																}
																if(contarSerrote>0) {
																	printf("\n Serrote: %i", contarSerrote);
																	serrote = serrote * contarSerrote;
																	printf("\n Total: R$%.2f", serrote);
																}
																printf("\n\n Comprador: %s", cad[indice].nome);
																printf("\n CNPJ: %i", cnpj[indice]);
																printf("\n Valor da compra: R$%.2f", carrinho);
																printf("\n ******* OBRIGADO PELA COMPRA ********\n\n");
																compraConfirmada = 1;
																pause;
															}
															if(resposta == 'N') {
																carrinho = atualizarCarrinho; //// voltar o valor original (sem desconto)
															}
															break;

														case 'C':
															printf("\n Cr�dito ");
															if(formaPagamento == 'C') {
																printf("\n Pagamento no Cr�dito n�o h� formas de desconto devido a taxas.");
															}
															printf("\n TOTAL A PAGAR: %.2f", carrinho);
															printf("\n Confirmar pagamento? (S/N)");
															buffer;
															scanf("%c", &resposta);
															resposta = toupper(resposta);
															buffer;
															if(resposta == 'S') {
																cls;
																printf("\n ********* PAGAMENTO CONFIRMADO *********");
																printf("\n\n");
																if(contarChaveFenda>0) {
																	printf("\n Chave de Fenda: %i", contarChaveFenda);
																	chaveFenda = chaveFenda * contarChaveFenda;
																	printf("\n Total: R$%.2f", chaveFenda);
																}
																if(contarChavePhillips>0) {
																	printf("\n Chave Phillips: %i", contarChavePhillips);
																	chavePhillips = chavePhillips * contarChavePhillips;
																	printf("\n Total: R$%.2f", chavePhillips);
																}
																if(contarChaveCanhao10mm>0) {
																	printf("\n Chave Canh�o 10mm: %i", contarChaveCanhao10mm);
																	chaveCanhao10mm = chaveCanhao10mm * contarChaveCanhao10mm;
																	printf("\n Total: R$%.2f", chaveCanhao10mm);
																}
																if(contarChaveBoca8mm>0) {
																	printf("\n Chave de Boca 8mm: %i", contarChaveBoca8mm);
																	chaveBoca8mm = chaveBoca8mm * contarChaveBoca8mm;
																	printf("\n Total: R$%.2f", chaveBoca8mm);
																}
																if(contarChaveBoca10mm>0) {
																	printf("\n Chave de Boca 10mm: %i", contarChaveBoca10mm);
																	chaveBoca10mm = chaveBoca10mm * contarChaveBoca10mm;
																	printf("\n Total: R$%.2f", chaveBoca10mm);
																}
																if(contarChaveBoca12mm>0) {
																	printf("\n Chave de Boca 12mm: %i", contarChaveBoca12mm);
																	chaveBoca12mm = chaveBoca12mm * contarChaveBoca12mm;
																	printf("\n Total: R$%.2f", chaveBoca12mm);
																}
																if(contarAlicateBico>0) {
																	printf("\n Alicate de Bico: %i", contarAlicateBico);
																	alicateBico = alicateBico * contarAlicateBico;
																	printf("\n Total: R$%.2f", alicateBico);
																}
																if(contarAlicateUniversal>0) {
																	printf("\n Alicate Universal: %i", contarAlicateUniversal);
																	alicateUniversal = alicateUniversal * contarAlicateUniversal;
																	printf("\n Total: R$%.2f", alicateUniversal);
																}
																if(contarAlicateCorte>0) {
																	printf("\n Alicate de Corte: %i", contarAlicateCorte);
																	alicateCorte = alicateCorte * contarAlicateCorte;
																	printf("\n Total: R$%.2f", alicateCorte);
																}
																if(contarPacoteParafusoFenda>0) {
																	printf("\n Pacote Parafuso Fenda: %i", contarPacoteParafusoFenda);
																	pacoteParafusoFenda = pacoteParafusoFenda * contarPacoteParafusoFenda;
																	printf("\n Total: R$%.2f", pacoteParafusoFenda);
																}
																if(contarPacoteParafusoPhillips>0) {
																	printf("\n Pacote Parafuso Phillips: %i", contarPacoteParafusoPhillips);
																	pacoteParafusoPhillips = pacoteParafusoPhillips * contarPacoteParafusoPhillips;
																	printf("\n Total: R$%.2f", pacoteParafusoPhillips);
																}
																if(contarPacoteParafusoSextavado>0) {
																	printf("\n Pacote Parafuso Sextavado: %i", contarPacoteParafusoSextavado);
																	pacoteParafusoSextavado = pacoteParafusoSextavado * contarPacoteParafusoSextavado;
																	printf("\n Total: R$%.2f", pacoteParafusoSextavado);
																}
																if(contarPacoteBuchaS6>0) {
																	printf("\n Pacote Bucha S6: %i", contarPacoteBuchaS6);
																	pacoteBuchaS6 = pacoteBuchaS6 * contarPacoteBuchaS6;
																	printf("\n Total: R$%.2f", pacoteBuchaS6);
																}
																if(contarPacoteBuchaS8>0) {
																	printf("\n Pacote Bucha S8: %i", contarPacoteBuchaS8);
																	pacoteBuchaS8 = pacoteBuchaS8 * contarPacoteBuchaS8;
																	printf("\n Total: R$%.2f", pacoteBuchaS8);
																}
																if(contarPacoteBuchaS10>0) {
																	printf("\n Pacote Bucha S10: %i", contarPacoteBuchaS10);
																	pacoteBuchaS10 = pacoteBuchaS10 * contarPacoteBuchaS10;
																	printf("\n Total: R$%.2f", pacoteBuchaS10);
																}
																if(contarFitaVedaRosca>0) {
																	printf("\n Fita Veda Rosca: %i", contarFitaVedaRosca);
																	fitaVedaRosca = fitaVedaRosca * contarFitaVedaRosca;
																	printf("\n Total: R$%.2f", fitaVedaRosca);
																}
																if(contarSerrote>0) {
																	printf("\n Serrote: %i", contarSerrote);
																	serrote = serrote * contarSerrote;
																	printf("\n Total: R$%.2f", serrote);
																}
																printf("\n\n Comprador: %s", cad[indice].nome);
																printf("\n CNPJ: %i", cnpj[indice]);
																printf("\n Valor da compra: R$%.2f", carrinho);
																printf("\n ******* OBRIGADO PELA COMPRA ********\n\n");
																compraConfirmada = 1;
																pause;
															}
															break;

													}
												} while(resposta == 'N');
											}
											if(carrinho == 0) {
												printf("\n Nenhum item foi adicionado ao carrinho.");
											}
											buffer;
											break;
									}
									if(compraConfirmada == 0) {
										printf("\n Carrinho: R$%.2f", carrinho);
										printf("\n Cancelar a compra? (S/N)"); /// cancelar tudo e recome�ar
										printf("\nR: ");
										scanf("%c", &resposta);
										resposta = toupper(resposta);
										if(resposta == 'S'){
											carrinho = 0;
											carrinhoFerramentas = 0;
											carrinhoParafusos = 0;
											carrinhoConstrucao = 0;
											contarAlicateBico = 0;
											contarAlicateUniversal = 0;
											contarAlicateCorte = 0;
											contarChavePhillips = 0;
											contarChaveFenda = 0;
											contarChaveCanhao10mm = 0;
											contarChaveBoca8mm = 0;
											contarChaveBoca10mm = 0;
											contarChaveBoca12mm = 0;
											contarPacoteParafusoFenda = 0;
											contarPacoteParafusoPhillips = 0;
											contarPacoteParafusoSextavado = 0;
											contarPacoteBuchaS6 = 0;
											contarPacoteBuchaS8 = 0;
											contarPacoteBuchaS10 = 0;
											contarFitaVedaRosca = 0;
											contarSerrote = 0;
										}
									}
									if(selecionar != 'F' && selecionar != 'P' && selecionar != 'C' && selecionar != 'D') {
										printf("\n Caracter errado. Tente novamente...\n");
									}
								} while(selecionar != 'F' && selecionar != 'P' && selecionar != 'C' && selecionar != 'D');
							} while(resposta == 'N' || compraConfirmada != 1);

						}
						break;
					case 'F':
						cls;
						printf ("\n\t\t\t ***************** CONTATO ******************\n");
						printf ("\n\t\t     Celular/WhatsApp: (61) 99723-6642 ");
						printf ("\n\t\t     Telefone fixo: (61) 8835-9932 ");
						printf ("\n\t\t     Atendimentos: Segunda - Sexta das 09:00h as 18:00h");
						printf ("\n\t\t     Atendimento final de semana: Sabado das 09:00h as 12:00h");
						printf ("\n\t\t     E-mail: dfdistribuidora@gmail.com\n");
						printf ("\n\t\t\t ********************************************\n");
						/// contato da empresa
						break;
				}
				buffer;
				if(selecionar != 'C' && selecionar != 'L' && selecionar != 'F' && selecionar != 'S') {
					printf("\nCaracter errado. Tente novamente...\n");
				}
			} while(selecionar != 'C' && selecionar != 'L' && selecionar != 'F' && selecionar != 'S');
			buffer;
			printf("\n");
			printf("\nContinuar? (S/N)");
			printf("\nR: ");
			scanf("%c", &resposta);
			resposta = toupper(resposta);
		} while(resposta == 'S');

		buffer;
		printf("\nFinalizar sess�o? ");
		printf("\n - (S) Sim ");
		printf("\n - (N) N�o ");
		printf("\nR:");
		scanf("%c", &resposta);
		resposta = toupper(resposta);
		if(resposta == 'N') {
			indice = indice + 1;
			carrinho = 0;
			flag2 = 0; // a flag ser� zerada para o castro de um novo usuario
			cls;
			buffer;
		}
	} while(resposta != 'S');
	return 0;
}//// fimPrincipal   /////////////////////////////////////

///Descricao
void descricao() {
	printf("\n\t\t   ****************** DESCRI��O ********************\n");
	printf("\n\t\t\t\tDF Distribuidora Ferragens.\n\n");
	printf("\t\t\t\t\tQuem Somos\n");
	printf("\n\t\tLocalizada no DF, a DFDF � bastante conhecida na regi�o\n\t\t\t e tamb�m pelo Brasil inteiro, \n\t\ttem objetivo de alcan�ar o topo de vendas e sempre\n\t\t    satisfazer os clientes da melhor maneira.\n ");
	printf("\n\t\t ************************************************** \n\n");
}

/// nome, email, cidade e usuario
char leValidaTexto(char texto[]) {
	do {
		gets(texto);
		if(strcmp(texto, "")==0) {
			printf("\n Campo obrigat�rio. Tente novamente...");
		}
	} while(strcmp(texto, "")==0);
	return texto[100];
}

/// cnpj
int leValidaInteiro(int inteiro[], int contador) {
	int valorInteiro, i, flag;
	i = 0;
	do {
		flag = 0;
		scanf("%i", &valorInteiro);
		for(i; i<contador; i++) {
			if(valorInteiro == inteiro[i]) {
				flag = 1; //indica se o cnpj � igual ou n�o
				break;
			}
		}
		if(flag == 1) {
			printf("\nCNPJ j� cadastrado, tente novamente...");
		}
	} while(flag == 1);
	return valorInteiro;
}

/// Telefone
int lerTelefone() {
	int telefone;

	scanf("%i", &telefone);
	return telefone;
}

/// Selecionar estado
int selecionarEstado() {
	int estado;
	printf("\nAcre (AC) = 1");
	printf("\nAlagoas (AL) = 2");
	printf("\nAmapa (AP) = 3");
	printf("\nAmazonas (AM) = 4");
	printf("\nBahia (BA) = 5");
	printf("\nCeara (CE) = 6");
	printf("\nDistrito Federal (DF) = 7");
	printf("\nEspirito Santo (ES) = 8");
	printf("\nGoias (GO) = 9");
	printf("\nMaranh�o (MA) = 10");
	printf("\nMato Grosso (MT) = 11");
	printf("\nMato Grosso do Sul (MS) = 12");
	printf("\nMinas Gerais (MG) = 13");
	printf("\nPar� (PA) = 14");
	printf("\nPara�ba (PB) = 15");
	printf("\nParan� (PR) = 16");
	printf("\nPernambuco (PE) = 17");
	printf("\nPiau� (PI) = 18");
	printf("\nRio de Janeiro (RJ) = 19");
	printf("\nRio Grande do Norte (RN) = 20");
	printf("\nRio Grande do Sul (RS) = 21");
	printf("\nRond�nia (RO) = 22");
	printf("\nRoraima (RR) = 23");
	printf("\nSanta Catarina (SC) = 24");
	printf("\nS�o Paulo (SP) = 25");
	printf("\nSergipe (SE) = 26");
	printf("\nTocantins (TO) = 27");
	do {
		printf("\nR:");
		scanf("%i", &estado);
		switch(estado) {
			case 1:
				printf("\nAcre (AC)");
				break;
			case 2:
				printf("\nAlagoas (AL)");
				break;
			case 3:
				printf("\nAmap� (AP)");
				break;
			case 4:
				printf("\nAmazonas (AM)");
				break;
			case 5:
				printf("\nBahia (BA)");
				break;
			case 6:
				printf("\nCear� (CE)");
				break;
			case 7:
				printf("\nDistrito Federal (DF)");
				break;
			case 8:
				printf("\nEspirito Santos (ES)");
				break;
			case 9:
				printf("\nGoi�s (GO)");
				break;
			case 10:
				printf("\nMaranh�o (MA)");
				break;
			case 11:
				printf("\nMato Grosso (MT)");
				break;
			case 12:
				printf("\nMato Grosso do Sul (MS)");
				break;
			case 13:
				printf("\nMinas Gerais (MG)");
				break;
			case 14:
				printf("\nPar� (PA)");
				break;
			case 15:
				printf("\nPara�ba (PB)");
				break;
			case 16:
				printf("\nParan� (PR)");
				break;
			case 17:
				printf("\nPernambuco (PE)");
				break;
			case 18:
				printf("\nPiau� (PI)");
				break;
			case 19:
				printf("\nRio de Janeiro (RJ)");
				break;
			case 20:
				printf("\nRio Grande do Norte (RN)");
				break;
			case 21:
				printf("\nRio Grande do Sul (RS)");
				break;
			case 22:
				printf("\nRond�nia (RO)");
				break;
			case 23:
				printf("\nRoraima (RR)");
				break;
			case 24:
				printf("\nSanta Catarina (SC)");
				break;
			case 25:
				printf("\nS�o Paulo (SP)");
				break;
			case 26:
				printf("\nSergipe (SE)");
				break;
			case 27:
				printf("\nTocantins (TO)");
				break;
			default:
				printf("\n N�mero n�o encontrado, tente novamente...");
		}
	} while(estado != 1 && estado != 2 && estado != 3 && estado != 4 && estado != 5 && estado != 6 &&
	        estado != 7 && estado != 8 && estado != 9 && estado != 10 && estado != 11 && estado != 12 && estado != 13 && estado != 14 &&
	        estado != 15 && estado != 16 && estado != 17 && estado != 18 && estado != 19 && estado != 20 && estado != 21 && estado != 22 &&
	        estado != 23 && estado != 24 && estado != 25 && estado != 26 && estado != 27);
	return estado;
}

//// Senha
char leValidaSenha(char *senha) {
	char  resposta, c;
	char confirmaSenha[100];
	int flag, i, j, a=0;
	do {
		i=0;
		do {
			a=0;
			buffer;
			//	system("cls");
			//printf("\nDigite uma Senha: ");
			do {
				c=getch();
				if(isprint(c)) {      //Analisa se o valor da vari�vel c � imprimivel
					senha[a]=c;  //Se for, armazena o caractere
					a++;
					printf("*");          //imprime o * Anterisco
				} else if(c==8&&a) {  //8 � o caractere BackSpace na tabela ASCII, && a analisa se a � diferente de 0
					senha[a]='\0';
					a--;
					printf("\b \b");       //Apagando o caractere digitado
				}
			} while(c!=13);             //13 � o valor de ENTER na tabela ASCII
			senha[a]='\0';
			//	printf("Senha: %s", login[j].senha);
			flag=0;
			buffer;
			a = 0;
			printf("\nConfirmar senha: ");
			//	scanf("%s", &confirmaSenha);
			buffer;
			do {
				c=getch();
				if(isprint(c)) {      //Analisa se o valor da vari�vel c � imprimivel
					confirmaSenha[a]=c;  //Se for, armazena o caractere
					a++;
					printf("*");          //imprime o * Anterisco
				} else if(c==8&&a) {  //8 � o caractere BackSpace na tabela ASCII, && a analisa se a � diferente de 0
					confirmaSenha[a]='\0';
					a--;
					printf("\b \b");       //Apagando o caractere digitado
				}
			} while(c!=13);             //13 � o valor de ENTER na tabela ASCII
			confirmaSenha[a]='\0';

			buffer;

			a=0;
			a = strcmp(confirmaSenha, senha); /// comparar a senhas
			if(a == 0) {
				printf("\nConfirmado!");
			} else {
				printf("\nConfirmacao de senha incorreta, Tente novamente...");
				flag=1;
			}
		} while(flag==1);
		printf("\nSenha: %s", senha);
		printf("\nConfirmar Senha?: (S/N)");
		printf("R:");
		scanf("%c", &resposta);
		resposta = toupper(resposta);
		buffer;
		if(resposta == 'S') {
			//j = j + 1;
			cls;
			printf("\nSenha cadastrada com sucesso!");
		}
	} while(resposta == 'N');
//	do {
//		int k, z=0;
//		i=0;
//		a=0;
//		flag = 0;
//		printf("\nSenha: ");
//		buffer;
//		gets(senha2);
//		buffer;
//		for(i; i<3; i++) {
//			a = strcmp(senha2, senha);
//			if(a==0) {
//				k = 1;
//				break;
//			}
//		}
//		if(k==1) {
//			printf("\n Bem vindo!");
//		} else {
//				printf("\n Senha Incorreta");
//				flag = 1;
//		}
//	} while(flag == 1);
	return senha[100];
}

/// acessar o cadastro com senha
int acessoSenha(char *senha, char *nome, int tentativas) {
	char senha2[100];
	int flag;
	do {
		int k, a, i;
		flag = 0;
		i=0;
		a=0;
		flag = 0;
		//printf("\nSenha: ");
		buffer;
		gets(senha2);
		buffer;
		for(i; i<3; i++) {
			a = strcmp(senha2, senha);
			if(a==0) {
				k = 1;
				return 1;
				break;
			}
		}
		if(k==1) {
			printf("\n Bem vindo!");
			printf("\n %s", nome);
		} else {
			printf("\n Senha Incorreta\n");
			flag = 1;
			tentativas--;
		}
		if(tentativas == 0) {
			printf("\n N�mero de tentativas foi excedido. ");
			return 0;
			break;
		}
	} while(flag == 1 || tentativas != 0);
}
