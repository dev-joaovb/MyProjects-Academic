#include <stdio.h>
#include <stdlib.h>

int main(){
	int numero;
	
	printf ("\n Informe um numero: ");
	scanf ("%i", &numero);
	
	printf ("\n Valor principal: %i", numero);
	printf ("\n Valor Sucessor: %i", numero + 1);
	printf ("\n Valor Antecessor: %i", numero - 1);
	return 0;
}
