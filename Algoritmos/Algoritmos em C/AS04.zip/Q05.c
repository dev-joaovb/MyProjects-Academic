#include <stdio.h>
#include <stdlib.h>

int main(){
	int razao, primeiroTermo, n, aN;
	
	printf ("\n Informe a Razao de uma P.A: ");
	scanf ("%i", &razao);
	printf ("\n Informe o primeiro termo de uma P.A: ");
	scanf ("%i", &primeiroTermo);
	printf ("\n Informe o valor de N: ");
	scanf ("%i", &n);
	
	aN = primeiroTermo + (n - 1) * razao;
	
	printf("\n O %i* termo de uma P.A: %i", n, aN);
	
	return 0;
}
