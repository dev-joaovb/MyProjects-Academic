#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(){
	float M, C, i;
	int t;
	
	printf ("\n Informe o valor do Capital inicial: \nR$");
	scanf ("%f", &C);
	printf ("\n Informe a taxa de juros a ser aplicada: ");
	scanf ("%f", &i);
	i = i/100;
	printf ("\n Informe o tempo acumulado: ");
	scanf("%i", &t);
	
	M = C * pow((1 + i), t);
	
	printf ("\n O Montante M = %f", M);
	
	
	return 0;
}

