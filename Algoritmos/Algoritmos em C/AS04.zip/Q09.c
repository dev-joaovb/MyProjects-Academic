#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(){
	int numero, resultado;
	
	printf ("\n Informe o valor de um log da base 10: ");
	scanf ("%i", &numero);
	
	resultado = log10(numero);
	printf("\n Valor = %i", resultado);
	
	return 0;
}
