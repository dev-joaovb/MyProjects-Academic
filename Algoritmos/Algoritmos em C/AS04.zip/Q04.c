#include <stdio.h>
#include <stdlib.h>

int main(){
	float Area, diagonalMaior, diagonalMenor;
	printf("\n Informe o valor da diagonal menor: ");
	scanf("%f", &diagonalMenor);
	printf("\n Informe o valor da diagonal maior: ");
	scanf("%f", &diagonalMaior);
	
	Area = (diagonalMenor * diagonalMaior)/2;
	printf("\n Valor da Area: %f", Area);
	return 0;
}
