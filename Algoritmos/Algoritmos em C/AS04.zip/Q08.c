#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(){
	float angulo;
	
	printf ("\n Informe um numero que sera um angulo: ");
	scanf ("%f", &angulo);
	
	printf("\n Seu seno: %f", sin(angulo));
	printf("\n Seu cosseno: %f", cos(angulo));
	printf("\n Seu tangente: %f", tan(angulo));
	
	return 0;
}
