#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(){
	float raio, altura, volume, pi=3.14;
	
	printf ("\n Informe o raio da lata: ");
	scanf ("%f", &raio);
	printf ("\n Informe a altura da lata: ");
	scanf ("%f", &altura);
	
	volume = pow(raio, 2)* (pi * altura);
	printf ("\n V = %f", volume);
	
	return 0;
}
