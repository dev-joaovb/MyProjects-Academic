#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(){
	float salarioMinimo = 998.0, kW=100, resultado;
	
	resultado = 998.0/7;
	resultado = resultado/100;
	printf ("\nO valor de cada kW: R$%0.f", resultado);
	resultado = 998.0/7;
	printf ("\nO valor a ser pago: R$%0.f", resultado);
	resultado = resultado - (resultado * 0.10);
	printf ("\n Valor dado por residencia com desconto de 10%%: %0.f", resultado);
	return 0;
}
