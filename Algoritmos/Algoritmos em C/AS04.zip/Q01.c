#include <stdio.h>
#include <stdlib.h>

int main(){
	float numero[3], media;
	int i;
	
	for (i=0; i < 3; i++){
		printf ("\n Informe o valor: ");
		scanf ("%f", &numero[i]);
	}
	for (i=0; i < 3; i++){
		media = media + numero[i];
	}
	media = media / 3;
	printf ("\n Media aritmetica: %f", media);
	return 0;
}
