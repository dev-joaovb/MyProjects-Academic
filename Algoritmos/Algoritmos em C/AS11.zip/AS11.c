#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#define MAX 9999

struct cadastro {
	int identificacao[MAX];
	int nivelEnvolvimento[MAX];
};
///
int leValidaIdentificado(int *identificado, int contador);
int leValidaNivel();
void ordenarValores(int indice, int envolvimento[]);
void iverterValores(int indice, int envolvimento[]);
///

int main() {
	struct cadastro cad;
	int indice = 0;
	char resposta;
	do { /// cadastros
		cad.identificacao[indice] = leValidaIdentificado(cad.identificacao, indice);
		cad.nivelEnvolvimento[indice] = leValidaNivel();
		indice = indice + 1;
		fflush(stdin);
		printf("\n Fazer outro cadastro?: (S/N)\n");
		printf("R: ");
		scanf("%c", &resposta);
		resposta = toupper(resposta);
	} while(resposta != 'N'); /// saida
	
	int i;
	
	for(i=0; i<indice; i++){
		ordenarValores(indice, cad.nivelEnvolvimento);
	}
	for(i=0; i<indice; i++){
		iverterValores(indice, cad.nivelEnvolvimento);
	}
	system("cls");
	i = 0;
	for(i; i<indice; i++) {
		printf("\n --------------- // -----------------");
		printf("\n Posicao: %i", i);
		printf("\n Nivel de Envolvimento: %i", cad.nivelEnvolvimento[i]);
		printf("\n Identificacao: %i", cad.identificacao[i]);
		printf("\n --------------- // -----------------\n");
	}

	return 0;
}

int leValidaIdentificado(int *identificado, int contador) {
	int flag, i = 0;
	int aux;
	do {
		printf("\n Informe o numero de identificacao do investigado a partir de 101 a 9.999: ");
		flag = 0;
		do {
			scanf("%i", &aux);
			if(aux < 101 || aux > 9999) {
				printf("\n O numero nao pode ser menor que 101 e maior que 10.000");
			}
		} while(aux < 101 || aux > 9999);

		for(i; i<contador; i++) {
			if(aux == identificado[i]) {
				flag = 1;
				break;
			}
		}
		if(flag == 1) {
			printf("\n Numero de investigacao ja cadastrado. Tente novamente com outro \n");
			system("pause");
			system("cls");
		}
	} while(flag == 1);
	return aux;
}

int leValidaNivel() {
	int numero;
	printf("\n Informe o nivel de envolvimento do investigado de 6 a 249: ");
	do {
		scanf("%i", &numero);
		if(numero < 6 || numero > 249) {
			printf("\n O numero nao pode ser menor que 6 e maior que 249. Tente novamente...\n");
		}
	} while(numero < 6 || numero > 249);
	return numero;
}

void ordenarValores(int indice, int envolvimento[]) {
	int i=0, z=0, aux;
	for(i=0; i<indice; i++) {
		for (z = i; z<indice; z++) {
			if(envolvimento[i]>envolvimento[z]) {
				aux = envolvimento[i];
				envolvimento[i] = envolvimento[z];
				envolvimento[z] = aux;
			}
		}
	}
}

void iverterValores(int indice, int envolvimento[]){
	int i=0, aux; 
	for (i=0; i<indice/2; i++) {
        aux = envolvimento[i];
        envolvimento[i] = envolvimento[indice-i-1];
        envolvimento[indice-i-1] = aux;
    }
}
