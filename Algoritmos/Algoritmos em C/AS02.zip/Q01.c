#include <stdlib.h>
#include <stdio.h>

int main(){
	int c;
	
	for (c = 'A'; c <= 'w'; c++) {
		if (c == 'A' || c == 'a' || c == 'C' || c == 'c' || c == 'F' || c == 'f' || c == 'W' || c == 'w'){
    		printf("%c Identificado.\n", c);
		}
	}

}
