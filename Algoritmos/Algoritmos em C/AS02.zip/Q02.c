#include <stdlib.h>
#include <stdio.h>

int main() {
	int nTermos, cont;
	float sTotal = 0;
	float temp = 0;

	scanf("%d", &nTermos);

	for(cont=1; cont<=nTermos; cont++) {

		temp = (400 - 5*cont)/(10 + 3*cont);

		if(cont%2 == 0) {  //se � entrada par
			sTotal -= temp;
			printf ("%f", sTotal);
		} else {
			sTotal+=temp;
			printf ("%f", sTotal);
		}
	}
}


