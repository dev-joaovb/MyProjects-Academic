#include <stdio.h>
#include <stdlib.h>

int main() {
	int  y,i=0;
	float x, pot=0;
	printf ("Entre com o valor base de X: ");
	scanf ("%f",&x);
	printf ("Entre com o valor expoente de Y: ");
	scanf ("%i",&y);

	for (i = 1; i < y; i++) {
		pot = x*(x*i);
	}
	printf ("\nO valor de X se elevado a Y sera de: %f", pot);

	return 0;
}
