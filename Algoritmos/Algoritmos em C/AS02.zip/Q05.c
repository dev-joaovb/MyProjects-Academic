#include <stdio.h>
#include <stdlib.h>

int main(){
	float vet1[10], vet2[10], vet3[10];
	int i;
	
	for (i=0; i < 9; i++){
		printf("\n Informe o primeiro valor: ");
		scanf("%f", &vet1[i]);
		printf("\n Informe o segundo valor: ");
		scanf("%f", &vet2[i]);
		printf("\n--------------------------");
		vet3[i] = vet1[i] * vet2[i];
	}
	for (i=0; i < 9; i++){
		printf ("\n %f * %f= %f", vet1[i], vet2[i], vet3[i]);
	}
	
	return 0;
}
