#include <stdio.h>
///funcao
int apresentaNumero();

int main() {
	int numero[5], i=0, n=0, aux=0;;

	numero[0] = apresentaNumero();
	numero[1] = apresentaNumero();
	numero[2] = apresentaNumero();
	numero[3] = apresentaNumero();
	numero[4] = apresentaNumero();


	for(i=0; i<5; i++) { /// Organizar na ordem as cadeiras
		for (n = i; n<5; n++) {
			if(numero[i]>numero[n]) {
				aux = numero[i];
				numero[i] = numero[n];
				numero[n] = aux;
			}
		}
	}
	for (i=0; i<5;i++){
		printf ("\n %i", numero[i]);
	}


	return 0;
}
int apresentaNumero() {
	int numero;
	printf("\n Informe um numero: ");
	scanf ("%i", &numero);
	return numero;
}
