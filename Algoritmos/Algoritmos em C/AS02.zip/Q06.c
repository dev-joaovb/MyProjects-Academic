#include <stdio.h>

int main() {
	int num1[20], num2[20], i=0;
	for(i=0; i < 19; i++) {
		printf("\nInforme os numeros: ");
		scanf ("%i",&num1[i]);

		if (num1[i] % 2 == 0) {
			num2[i] = num1[i] % 2;
		} else {
			num2[i] = num1[i] * 3;
		}

	}
	
	for(i=0; i < 19; i++) {

		if (num1[i] % 2 == 0) {
			printf ("\nO numero %i eh par\n",num2[i]);
		} else {
			printf("\nO numero %i eh impar\n",num2[i]);
		}

	}
	return 0;
}
