#include <stdio.h>
#include <stdlib.h>

int main( )
{
int i, j;
int mat1[4][8], mat2[4][8], mat3[4][8];

/*la�o de repeti��o para entrar com os valores da matriz 1*/
for (i=0; i<4; i++) {
for(j=0; j<8; j++)
{
printf(" Entre com os elementos da matriz 1 [%d][%d]:",i+1,j+1);
scanf("%d",&mat1[i][j]);

printf(" Entre com os elementos da matriz 2 [%d][%d]:",i+1,j+1);
scanf("%d",&mat2[i][j]);

//soma as 2 matrizes criadas
mat3[i][j] = mat1[i][j] + mat2[i][j];

}
}

/*Mostra a matriz 1 criada*/
printf("\n\nA matriz 1 criada eh: \n\n");
for (i=0; i<4; i++)
{
for(j=0; j<8;j++)
printf("%3.d\t",mat1[i][j]);
printf("\n\n");
}

/*Mostra a matriz 2 criada*/
printf("\n\nA matriz 2 criada eh: \n\n");
for (i=0; i<4; i++)
{
for(j=0; j<8;j++)
printf("%3.d\t",mat2[i][j]);
printf("\n\n");
}

/*Mostra a matriz 3 (soma) criada*/
printf("\n\nA matriz soma eh: \n\n");
for (i=0; i<4; i++)
{
for(j=0; j<8;j++)
printf("%3.d\t",mat3[i][j]);
printf("\n\n");
}

printf("\n\n\n");
getch();
return 0;

}

