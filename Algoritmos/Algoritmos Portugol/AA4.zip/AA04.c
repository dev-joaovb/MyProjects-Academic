#include <stdio.h>
#include <stdlib.h>

int main(){
	int colunaM[6][6], colunaSC[6], colunaSL[6];
	int i, j;
	for (i=0; i < 6; i++){
		for(j=0; j < 6; j++){
			printf("\nInforme um valor [%i][%i] = ", i, j);
			scanf("%i", &colunaM[i][j]);
			
			colunaSC[i] = colunaSC[i] + colunaM[i][j];
			printf("\n Valor[%i] = ", colunaSC[i]);
		}
		printf("\n");
	}
	
	return 0;
}
