// Joao victor bueno
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(){
	float vet[20], S;
	int i;
	
	for (i=0; i < 20; i++){
		printf ("\nInforme o valor: ");
		scanf ("%f", &vet[i]);
	}
	S= (pow((vet[0]- vet[19]), 2) + pow((vet[1]- vet[18]), 2) + pow((vet[2]- vet[17]), 2) + pow((vet[3]- vet[16]), 2) + pow((vet[4]- vet[15]), 2) +
	pow((vet[5]- vet[14]), 2) + pow((vet[6]- vet[13]), 2) + pow((vet[7]- vet[12]), 2) + pow((vet[8]- vet[11]), 2) + pow((vet[9]- vet[10]), 2));
	
	printf("\n S = %f", S);
	return 0;
}
