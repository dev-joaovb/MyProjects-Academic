#include <math.h>
#include <stdio.h>

void insertionSort(int arr[], int n);
int buscaBinaria(int arr[],int tamanho, int chave);

int main(){
	int maximo;
	printf ("\n Informe a quantidade de numeros: ");
	scanf ("%i", &maximo);
    int arr[maximo];
    int n = sizeof(arr) / sizeof(arr[0]);
    int i, pesquisa, resultado;
    
    for(i=0; i<maximo; i++){
    printf("\n Informe o valor: ");
    scanf("%i", &arr[i]);
	}
    
	insertionSort(arr, n);
    
	for (i = 0; i < n; i++){
        printf("%d ", arr[i]);
    printf("\n");
	}
	/////
	printf("\n Informe um numero para pesquisa: ");
	scanf("%i", &pesquisa);
	resultado = buscaBinaria(arr, maximo, pesquisa);
	
	if(resultado == -1){
		printf("\nValor nao encontrado....");
	}else{
		printf("\nValor encontrado na posicao: %i", resultado);
	}
    return 0;
}

void insertionSort(int arr[], int n){
    int i, key, j;
    for (i = 1; i < n; i++) {
        key = arr[i];
        j = i - 1;
        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            j = j - 1;
        }
        arr[j + 1] = key;
    }
}

int buscaBinaria(int arr[],int tamanho, int chave) {	 
	int i = 0;
	int f = tamanho -1;
	int meio;
	while (i<=f) {
		meio = (i+f)/2;
		if (arr[meio]==chave)
			return meio;
		else {
			if (chave>arr[meio])
				i=meio+1;
			else
				f=meio-1;
		}
	}
	return -1;
}
