#include <stdio.h>
#include <stdlib.h>

struct aluno{
	char nome[50];
	float nota[4];
};

int main(){
	struct aluno aluno;
	int i;
	float media;
	
	printf ("\n Informe o nome: ");
	fgets(aluno.nome, 50, stdin);
	for (i=0; i<4; i++){
		printf ("\n Informe a nota: ");
		scanf("%f", &aluno.nota[i]);
		media = media + aluno.nota[i];
	}
	media = media/4;
	for (i=0; i<4; i++){
		printf ("\nNota: %f", aluno.nota[i]);
	}
	printf ("\n Nome: %s", aluno.nome);
	printf ("\n Media: %f", media);
	
	
	
	
}
