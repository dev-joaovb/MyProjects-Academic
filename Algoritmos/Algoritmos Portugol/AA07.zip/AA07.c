#include <stdio.h>
#include <stdlib.h>

struct identidade{
	char nome[50], endereco[200];
	char sexo[10];
	int rg, dia, mes, ano;
	float salario;
};


int main(){
	struct identidade ident;
	printf("\n Informe o nome da identidade: ");
	fgets(ident.nome, 50, stdin);
	printf ("\n Informe o endereco: ");
	fgets(ident.endereco, 200, stdin);
	printf("\n Informe o sexo: ");
	fgets(ident.sexo, 10, stdin);
	printf("\n Informe o RG: ");
	scanf("%i", &ident.rg);
	printf ("\n Informe o dia de nascimento: ");
	scanf("%i", &ident.dia);
	printf ("\n Informe o mes de nascimento: ");
	scanf("%i", &ident.mes);
	printf ("\n Informe o ano de nascimento: ");
	scanf("%i", &ident.ano);
	printf ("\n Informe o salario: ");
	scanf("%f", &ident.salario);
	system("cls");
	printf ("\n Nome: %s", ident.nome);
	printf ("\n Endereco: %s", ident.endereco);
	printf ("\n Sexo: %s", ident.sexo);
	printf ("\n RG: %i", ident.rg);
	printf ("\n Salario: %f", ident.salario);
	printf ("\n Nascimento: %i/%i/%i", ident.dia, ident.mes, ident.ano);
	return 0;
}
